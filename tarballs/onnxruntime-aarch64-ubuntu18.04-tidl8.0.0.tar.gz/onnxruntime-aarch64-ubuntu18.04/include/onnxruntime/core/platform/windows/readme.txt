copied from minkernel/published/internal/telemetry/open_source/TraceLoggingConfig.h 
this is the official open source edition for these configuration settings